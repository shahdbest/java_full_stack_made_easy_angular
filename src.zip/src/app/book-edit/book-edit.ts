import { ChangeDetectorRef, Component } from '@angular/core';
import { Book } from '../book.model';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../book-service';

@Component({
  selector: 'app-book-edit',
  standalone: false,
  templateUrl: './book-edit.html',
  styleUrl: './book-edit.css',
})
export class BookEdit {
book: Book = { id: 0, title: '', author: '', price: 0 };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: BookService,
    private cdr:ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.loadBook(id);
  }

  loadBook(id: number) {
    this.service.getBookById(id).subscribe(data => {
      this.book = data;
      this.cdr.detectChanges();
    });
  }

  update() {
    this.service.updateBook(this.book).subscribe(() => {
      alert("Book updated successfully!");
      this.router.navigate(['/']);
    });
  }
}
