import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Book } from '../book.model';
import { BookService } from '../book-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-list',
  standalone: false,
  templateUrl: './book-list.html',
  styleUrl: './book-list.css',
})
export class BookList implements OnInit{
  books: Book[] = [];

  constructor(private service: BookService, private router: Router
    ,
     private cdr: ChangeDetectorRef
  )
   {}

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks() {
    this.service.getBooks().subscribe(data => {
      this.books = data;
      this.cdr.detectChanges();
    });
  }

  deleteBook(id: number) {
    this.service.deleteBook(id).subscribe(() => {
      this.loadBooks();
    });
  }
}
