import { Component } from '@angular/core';
import { BookService } from '../book-service';
import { Router } from '@angular/router';
import { Book } from '../book.model';


@Component({
  selector: 'app-book-add',
  standalone: false,
  templateUrl: './book-add.html',
  styleUrl: './book-add.css',
})
export class BookAdd {
 book: Book = { id: 0, title: '', author: '', price: 0 };

  constructor(private service: BookService, private router: Router) {}

  save() {
    this.service.addBook(this.book).subscribe(() => {
      this.router.navigate(['/']);
    });
  }
}
