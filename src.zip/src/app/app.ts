import { Component, OnInit, signal } from '@angular/core';
import { CarService } from './car-service';
import { Car } from '../car.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  standalone: false,
  styleUrl: './app.css'
})
export class App implements OnInit{
ngOnInit(): void {
  
}
}
