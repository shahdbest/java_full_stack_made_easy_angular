import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookList } from './book-list/book-list';
import { BookAdd } from './book-add/book-add';
import { BookEdit } from './book-edit/book-edit';
import { BookView } from './book-view/book-view';

const routes: Routes = [
 { path: '', redirectTo: 'home', pathMatch: 'full' }, // default route

  { path: 'home', component: BookList },
  { path: 'add', component: BookAdd },
  { path: 'edit/:id', component: BookEdit },
  { path: 'view/:id', component: BookView },

  // optional: wildcard route to avoid blank white page on wrong URL
  { path: '**', redirectTo: '/home' }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
