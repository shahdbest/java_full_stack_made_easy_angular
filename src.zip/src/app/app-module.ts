import { NgModule, provideBrowserGlobalErrorListeners, provideZonelessChangeDetection } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BookList } from './book-list/book-list';
import { BookEdit } from './book-edit/book-edit';
import { BookAdd } from './book-add/book-add';
import { BookView } from './book-view/book-view';

@NgModule({
  declarations: [
    App,
    BookList,
    BookEdit,
    BookAdd,
    BookView
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection()
  ],
  bootstrap: [App]
})
export class AppModule { }
