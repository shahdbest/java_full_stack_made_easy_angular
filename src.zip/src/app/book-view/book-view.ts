import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../book-service';
import { Book } from '../book.model';

@Component({
  selector: 'app-book-view',
  standalone: false,
  templateUrl: './book-view.html',
  styleUrl: './book-view.css',
})
export class BookView implements OnInit{
 book: Book = { id: 0, title: '', author: '', price: 0 };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: BookService,
    private cdr:ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.loadBook(id);
  }

  loadBook(id: number) {
    this.service.getBookById(id).subscribe(
      data => {
      this.book = data;
        this.cdr.detectChanges();
    },
    error=>{
      console.log(error)
    }
  );
  }

  goBack() {
    this.router.navigate(['/']);
  }
}
