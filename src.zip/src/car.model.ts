export class Car{
        id="";
        name="";
        maker= "";
        color="";
}