import { NgModule, provideBrowserGlobalErrorListeners, provideZonelessChangeDetection } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { SuperheroListComponent } from './superhero-list-component/superhero-list-component';
import { SuperheroAddComponent } from './superhero-add-component/superhero-add-component';
import { SuperheroViewComponent } from './superhero-view-component/superhero-view-component';
import { SuperheroEditComponent } from './superhero-edit-component/superhero-edit-component';

@NgModule({
  declarations: [
    App,
    SuperheroListComponent,
    SuperheroAddComponent,
    SuperheroViewComponent,
    SuperheroEditComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection()
  ],
  bootstrap: [App]
})
export class AppModule { }
