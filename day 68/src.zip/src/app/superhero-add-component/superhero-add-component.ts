import { Component } from '@angular/core';
import { SuperheroService } from '../superhero-service';
import { SuperHero } from '../../superhero.model';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-superhero-add-component',
  standalone: false,
  templateUrl: './superhero-add-component.html',
  styleUrl: './superhero-add-component.css',
})
export class SuperheroAddComponent {

hero=new SuperHero();
  constructor(private heroService:SuperheroService,private myrouter:Router)
  {}


  save(){
    this.heroService.addHero(this.hero).subscribe(

      data=>{
        alert('hero added');
        this.myrouter.navigate(['/heros'])
      },
      error=>{
        console.log(error);
      }

    )
  }

}
