import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SuperHero } from '../superhero.model';

@Injectable({
  providedIn: 'root',
})
export class SuperheroService {

  private baseUrl="http://localhost:3000/superheros";

  constructor(private http:HttpClient){

  }
  
  getHeros(){
    return this.http.get<SuperHero[]>(this.baseUrl);
  }

  getHeroById(id:string){
    return this.http.get<SuperHero>(`${this.baseUrl}/${id}`);
  }

  addHero(hero:SuperHero){
    return this.http.post<SuperHero>(this.baseUrl,hero);
  }


    updateHero(hero:SuperHero){
    return this.http.put<SuperHero>(`${this.baseUrl}/${hero.id}`,hero);
  }

  deleteHero(id:string){
    return this.http.delete(`${this.baseUrl}/${id}`);
  }


}
