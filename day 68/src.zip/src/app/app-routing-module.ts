import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SuperheroListComponent } from './superhero-list-component/superhero-list-component';
import { SuperheroAddComponent } from './superhero-add-component/superhero-add-component';
import { SuperheroEditComponent } from './superhero-edit-component/superhero-edit-component';
import { SuperheroViewComponent } from './superhero-view-component/superhero-view-component';

const routes: Routes = [
  {path:'',redirectTo:'heros',pathMatch:'full'},
  {path:'heros',component:SuperheroListComponent},
  {path:'heros/add',component:SuperheroAddComponent},
 {path:'heros/edit/:id',component:SuperheroEditComponent},
 {path:'heros/view/:id',component:SuperheroViewComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
