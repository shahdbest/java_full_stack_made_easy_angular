import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperheroViewComponent } from './superhero-view-component';

describe('SuperheroViewComponent', () => {
  let component: SuperheroViewComponent;
  let fixture: ComponentFixture<SuperheroViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SuperheroViewComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SuperheroViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
