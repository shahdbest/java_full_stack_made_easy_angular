import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { SuperHero } from '../../superhero.model';
import { SuperheroService } from '../superhero-service';

@Component({
  selector: 'app-superhero-list-component',
  standalone: false,
  templateUrl: './superhero-list-component.html',
  styleUrl: './superhero-list-component.css',
})
export class SuperheroListComponent  implements OnInit{

  heros:SuperHero[]=[];


  constructor(private heroService:SuperheroService, private cdr:ChangeDetectorRef)
  {

  }

ngOnInit(): void {
  this.loadHeros();
}

  loadHeros()
  {
    this.heroService.getHeros().subscribe(
      data=>{
        this.heros=data;
        this.cdr.detectChanges();
      },
      error=>{
        console.log(error)
      }

    )
  }


  deleteHero(id:string){

    this.heroService.deleteHero(id).subscribe(

      data=>{
        alert('hero deleted')
        this.loadHeros();
        this.cdr.detectChanges();

      },
      error=>{
        console.log(error)
      }

    )

  }
}
