export class SuperHero{

    id:string="";
    name:string="";
    power:string="";
    universe:string="";

}